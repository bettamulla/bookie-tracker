# Matched Betting Tracker PWA

This is a GitHub Pages–ready bundle.

## Deploy

1. Put these files in the root of your repo.
2. Enable GitHub Pages (Settings → Pages → Source: main branch, / (root)).
3. Visit https://USERNAME.github.io/REPO/ .

## PWA

- App name and icons are defined in `manifest.webmanifest` and `/icons/`.
- Service worker is in `sw.js`. Cache version: v2-c842e9.
- To force update, bump the CACHE string in sw.js.
